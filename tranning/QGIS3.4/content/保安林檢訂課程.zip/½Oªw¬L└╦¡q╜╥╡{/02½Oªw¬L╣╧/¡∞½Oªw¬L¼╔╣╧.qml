<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyLocal="1" simplifyDrawingTol="1" minScale="100000000" version="3.14.15-Pi" maxScale="0" simplifyDrawingHints="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" simplifyAlgorithm="0" hasScaleBasedVisibilityFlag="0" labelsEnabled="0" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <temporal accumulate="0" fixedDuration="0" durationUnit="min" startField="" mode="0" durationField="" endField="" startExpression="" enabled="0" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 forceraster="0" symbollevels="0" enableorderby="0" type="singleSymbol">
    <symbols>
      <symbol clip_to_extent="1" force_rhr="0" name="0" type="fill" alpha="1">
        <layer class="SimpleLine" pass="0" locked="0" enabled="1">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="228,26,28,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.76"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <property value="0" key="embeddedWidgets/count"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory spacing="5" labelPlacementMethod="XHeight" scaleBasedVisibility="0" minScaleDenominator="0" diagramOrientation="Up" lineSizeType="MM" scaleDependency="Area" showAxis="1" penAlpha="255" spacingUnitScale="3x:0,0,0,0,0,0" enabled="0" rotationOffset="270" backgroundAlpha="255" sizeType="MM" minimumSize="0" lineSizeScale="3x:0,0,0,0,0,0" width="15" maxScaleDenominator="1e+08" penColor="#000000" opacity="1" direction="0" sizeScale="3x:0,0,0,0,0,0" barWidth="5" spacingUnit="MM" backgroundColor="#ffffff" penWidth="0" height="15">
      <fontProperties style="" description="PMingLiU,9,-1,5,50,0,0,0,0,0"/>
      <axisSymbol>
        <symbol clip_to_extent="1" force_rhr="0" name="" type="line" alpha="1">
          <layer class="SimpleLine" pass="0" locked="0" enabled="1">
            <prop k="capstyle" v="square"/>
            <prop k="customdash" v="5;2"/>
            <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="customdash_unit" v="MM"/>
            <prop k="draw_inside_polygon" v="0"/>
            <prop k="joinstyle" v="bevel"/>
            <prop k="line_color" v="35,35,35,255"/>
            <prop k="line_style" v="solid"/>
            <prop k="line_width" v="0.26"/>
            <prop k="line_width_unit" v="MM"/>
            <prop k="offset" v="0"/>
            <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="offset_unit" v="MM"/>
            <prop k="ring_filter" v="0"/>
            <prop k="use_custom_dash" v="0"/>
            <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings priority="0" linePlacementFlags="18" zIndex="0" obstacle="0" showAll="1" placement="1" dist="0">
    <properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option name="QgsGeometryGapCheck" type="Map">
        <Option value="0" name="allowedGapsBuffer" type="double"/>
        <Option value="false" name="allowedGapsEnabled" type="bool"/>
        <Option value="" name="allowedGapsLayer" type="QString"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="宗地母">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="宗地子">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="段碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="段延碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="段號">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="轉檔日">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="地號">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="登日期">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="登因碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="地目碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="等則碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="登面積">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="使分碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="使類碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="公告值">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="公告價">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="縣市碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="鄉鎮碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="事所碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="小段碼">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="地段延">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Shape_Leng">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Shape_Area">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="橫坐標">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="縱坐標">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="登因">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="使分">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="使類">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="地目">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="事所名">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="段">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="小段">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="縣市">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="鄉鎮">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="宗地母" name="" index="0"/>
    <alias field="宗地子" name="" index="1"/>
    <alias field="段碼" name="" index="2"/>
    <alias field="段延碼" name="" index="3"/>
    <alias field="段號" name="" index="4"/>
    <alias field="轉檔日" name="" index="5"/>
    <alias field="地號" name="" index="6"/>
    <alias field="登日期" name="" index="7"/>
    <alias field="登因碼" name="" index="8"/>
    <alias field="地目碼" name="" index="9"/>
    <alias field="等則碼" name="" index="10"/>
    <alias field="登面積" name="" index="11"/>
    <alias field="使分碼" name="" index="12"/>
    <alias field="使類碼" name="" index="13"/>
    <alias field="公告值" name="" index="14"/>
    <alias field="公告價" name="" index="15"/>
    <alias field="縣市碼" name="" index="16"/>
    <alias field="鄉鎮碼" name="" index="17"/>
    <alias field="事所碼" name="" index="18"/>
    <alias field="小段碼" name="" index="19"/>
    <alias field="地段延" name="" index="20"/>
    <alias field="Shape_Leng" name="" index="21"/>
    <alias field="Shape_Area" name="" index="22"/>
    <alias field="橫坐標" name="" index="23"/>
    <alias field="縱坐標" name="" index="24"/>
    <alias field="登因" name="" index="25"/>
    <alias field="使分" name="" index="26"/>
    <alias field="使類" name="" index="27"/>
    <alias field="地目" name="" index="28"/>
    <alias field="事所名" name="" index="29"/>
    <alias field="段" name="" index="30"/>
    <alias field="小段" name="" index="31"/>
    <alias field="縣市" name="" index="32"/>
    <alias field="鄉鎮" name="" index="33"/>
  </aliases>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <defaults>
    <default expression="" field="宗地母" applyOnUpdate="0"/>
    <default expression="" field="宗地子" applyOnUpdate="0"/>
    <default expression="" field="段碼" applyOnUpdate="0"/>
    <default expression="" field="段延碼" applyOnUpdate="0"/>
    <default expression="" field="段號" applyOnUpdate="0"/>
    <default expression="" field="轉檔日" applyOnUpdate="0"/>
    <default expression="" field="地號" applyOnUpdate="0"/>
    <default expression="" field="登日期" applyOnUpdate="0"/>
    <default expression="" field="登因碼" applyOnUpdate="0"/>
    <default expression="" field="地目碼" applyOnUpdate="0"/>
    <default expression="" field="等則碼" applyOnUpdate="0"/>
    <default expression="" field="登面積" applyOnUpdate="0"/>
    <default expression="" field="使分碼" applyOnUpdate="0"/>
    <default expression="" field="使類碼" applyOnUpdate="0"/>
    <default expression="" field="公告值" applyOnUpdate="0"/>
    <default expression="" field="公告價" applyOnUpdate="0"/>
    <default expression="" field="縣市碼" applyOnUpdate="0"/>
    <default expression="" field="鄉鎮碼" applyOnUpdate="0"/>
    <default expression="" field="事所碼" applyOnUpdate="0"/>
    <default expression="" field="小段碼" applyOnUpdate="0"/>
    <default expression="" field="地段延" applyOnUpdate="0"/>
    <default expression="" field="Shape_Leng" applyOnUpdate="0"/>
    <default expression="" field="Shape_Area" applyOnUpdate="0"/>
    <default expression="" field="橫坐標" applyOnUpdate="0"/>
    <default expression="" field="縱坐標" applyOnUpdate="0"/>
    <default expression="" field="登因" applyOnUpdate="0"/>
    <default expression="" field="使分" applyOnUpdate="0"/>
    <default expression="" field="使類" applyOnUpdate="0"/>
    <default expression="" field="地目" applyOnUpdate="0"/>
    <default expression="" field="事所名" applyOnUpdate="0"/>
    <default expression="" field="段" applyOnUpdate="0"/>
    <default expression="" field="小段" applyOnUpdate="0"/>
    <default expression="" field="縣市" applyOnUpdate="0"/>
    <default expression="" field="鄉鎮" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" exp_strength="0" field="宗地母" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="宗地子" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="段碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="段延碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="段號" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="轉檔日" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="地號" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="登日期" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="登因碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="地目碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="等則碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="登面積" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="使分碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="使類碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="公告值" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="公告價" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="縣市碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="鄉鎮碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="事所碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="小段碼" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="地段延" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="Shape_Leng" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="Shape_Area" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="橫坐標" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="縱坐標" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="登因" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="使分" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="使類" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="地目" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="事所名" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="段" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="小段" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="縣市" notnull_strength="0" constraints="0"/>
    <constraint unique_strength="0" exp_strength="0" field="鄉鎮" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="宗地母"/>
    <constraint exp="" desc="" field="宗地子"/>
    <constraint exp="" desc="" field="段碼"/>
    <constraint exp="" desc="" field="段延碼"/>
    <constraint exp="" desc="" field="段號"/>
    <constraint exp="" desc="" field="轉檔日"/>
    <constraint exp="" desc="" field="地號"/>
    <constraint exp="" desc="" field="登日期"/>
    <constraint exp="" desc="" field="登因碼"/>
    <constraint exp="" desc="" field="地目碼"/>
    <constraint exp="" desc="" field="等則碼"/>
    <constraint exp="" desc="" field="登面積"/>
    <constraint exp="" desc="" field="使分碼"/>
    <constraint exp="" desc="" field="使類碼"/>
    <constraint exp="" desc="" field="公告值"/>
    <constraint exp="" desc="" field="公告價"/>
    <constraint exp="" desc="" field="縣市碼"/>
    <constraint exp="" desc="" field="鄉鎮碼"/>
    <constraint exp="" desc="" field="事所碼"/>
    <constraint exp="" desc="" field="小段碼"/>
    <constraint exp="" desc="" field="地段延"/>
    <constraint exp="" desc="" field="Shape_Leng"/>
    <constraint exp="" desc="" field="Shape_Area"/>
    <constraint exp="" desc="" field="橫坐標"/>
    <constraint exp="" desc="" field="縱坐標"/>
    <constraint exp="" desc="" field="登因"/>
    <constraint exp="" desc="" field="使分"/>
    <constraint exp="" desc="" field="使類"/>
    <constraint exp="" desc="" field="地目"/>
    <constraint exp="" desc="" field="事所名"/>
    <constraint exp="" desc="" field="段"/>
    <constraint exp="" desc="" field="小段"/>
    <constraint exp="" desc="" field="縣市"/>
    <constraint exp="" desc="" field="鄉鎮"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns>
      <column hidden="0" name="宗地母" width="-1" type="field"/>
      <column hidden="0" name="宗地子" width="-1" type="field"/>
      <column hidden="0" name="段碼" width="-1" type="field"/>
      <column hidden="0" name="段延碼" width="-1" type="field"/>
      <column hidden="0" name="段號" width="-1" type="field"/>
      <column hidden="0" name="轉檔日" width="-1" type="field"/>
      <column hidden="0" name="地號" width="-1" type="field"/>
      <column hidden="0" name="登日期" width="-1" type="field"/>
      <column hidden="0" name="登因碼" width="-1" type="field"/>
      <column hidden="0" name="地目碼" width="-1" type="field"/>
      <column hidden="0" name="等則碼" width="-1" type="field"/>
      <column hidden="0" name="登面積" width="-1" type="field"/>
      <column hidden="0" name="使分碼" width="-1" type="field"/>
      <column hidden="0" name="使類碼" width="-1" type="field"/>
      <column hidden="0" name="公告值" width="-1" type="field"/>
      <column hidden="0" name="公告價" width="-1" type="field"/>
      <column hidden="0" name="縣市碼" width="-1" type="field"/>
      <column hidden="0" name="鄉鎮碼" width="-1" type="field"/>
      <column hidden="0" name="事所碼" width="-1" type="field"/>
      <column hidden="0" name="小段碼" width="-1" type="field"/>
      <column hidden="0" name="地段延" width="-1" type="field"/>
      <column hidden="0" name="Shape_Leng" width="-1" type="field"/>
      <column hidden="0" name="Shape_Area" width="-1" type="field"/>
      <column hidden="0" name="橫坐標" width="-1" type="field"/>
      <column hidden="0" name="縱坐標" width="-1" type="field"/>
      <column hidden="0" name="登因" width="-1" type="field"/>
      <column hidden="0" name="使分" width="-1" type="field"/>
      <column hidden="0" name="使類" width="-1" type="field"/>
      <column hidden="0" name="地目" width="-1" type="field"/>
      <column hidden="0" name="事所名" width="-1" type="field"/>
      <column hidden="0" name="段" width="-1" type="field"/>
      <column hidden="0" name="小段" width="-1" type="field"/>
      <column hidden="0" name="縣市" width="-1" type="field"/>
      <column hidden="0" name="鄉鎮" width="-1" type="field"/>
      <column hidden="1" width="-1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="Shape_Area"/>
    <field editable="1" name="Shape_Leng"/>
    <field editable="1" name="事所名"/>
    <field editable="1" name="事所碼"/>
    <field editable="1" name="使分"/>
    <field editable="1" name="使分碼"/>
    <field editable="1" name="使類"/>
    <field editable="1" name="使類碼"/>
    <field editable="1" name="公告值"/>
    <field editable="1" name="公告價"/>
    <field editable="1" name="地段延"/>
    <field editable="1" name="地目"/>
    <field editable="1" name="地目碼"/>
    <field editable="1" name="地號"/>
    <field editable="1" name="宗地子"/>
    <field editable="1" name="宗地母"/>
    <field editable="1" name="小段"/>
    <field editable="1" name="小段碼"/>
    <field editable="1" name="橫坐標"/>
    <field editable="1" name="段"/>
    <field editable="1" name="段延碼"/>
    <field editable="1" name="段碼"/>
    <field editable="1" name="段號"/>
    <field editable="1" name="登因"/>
    <field editable="1" name="登因碼"/>
    <field editable="1" name="登日期"/>
    <field editable="1" name="登面積"/>
    <field editable="1" name="等則碼"/>
    <field editable="1" name="縣市"/>
    <field editable="1" name="縣市碼"/>
    <field editable="1" name="縱坐標"/>
    <field editable="1" name="轉檔日"/>
    <field editable="1" name="鄉鎮"/>
    <field editable="1" name="鄉鎮碼"/>
  </editable>
  <labelOnTop>
    <field name="Shape_Area" labelOnTop="0"/>
    <field name="Shape_Leng" labelOnTop="0"/>
    <field name="事所名" labelOnTop="0"/>
    <field name="事所碼" labelOnTop="0"/>
    <field name="使分" labelOnTop="0"/>
    <field name="使分碼" labelOnTop="0"/>
    <field name="使類" labelOnTop="0"/>
    <field name="使類碼" labelOnTop="0"/>
    <field name="公告值" labelOnTop="0"/>
    <field name="公告價" labelOnTop="0"/>
    <field name="地段延" labelOnTop="0"/>
    <field name="地目" labelOnTop="0"/>
    <field name="地目碼" labelOnTop="0"/>
    <field name="地號" labelOnTop="0"/>
    <field name="宗地子" labelOnTop="0"/>
    <field name="宗地母" labelOnTop="0"/>
    <field name="小段" labelOnTop="0"/>
    <field name="小段碼" labelOnTop="0"/>
    <field name="橫坐標" labelOnTop="0"/>
    <field name="段" labelOnTop="0"/>
    <field name="段延碼" labelOnTop="0"/>
    <field name="段碼" labelOnTop="0"/>
    <field name="段號" labelOnTop="0"/>
    <field name="登因" labelOnTop="0"/>
    <field name="登因碼" labelOnTop="0"/>
    <field name="登日期" labelOnTop="0"/>
    <field name="登面積" labelOnTop="0"/>
    <field name="等則碼" labelOnTop="0"/>
    <field name="縣市" labelOnTop="0"/>
    <field name="縣市碼" labelOnTop="0"/>
    <field name="縱坐標" labelOnTop="0"/>
    <field name="轉檔日" labelOnTop="0"/>
    <field name="鄉鎮" labelOnTop="0"/>
    <field name="鄉鎮碼" labelOnTop="0"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"宗地母"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
